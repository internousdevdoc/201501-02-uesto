package jp.co.internous.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.internous.dao.GoCartDAO;
import jp.co.internous.dto.GoCartDTO;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public class Go2CartAction extends ActionSupport implements SessionAware{

	public List<GoCartDTO> cartList = new ArrayList<GoCartDTO>();
	public List<GoCartDTO> checkList = new ArrayList<GoCartDTO>();
	public int goods_id;
	public Map<String,Object> sessionMap;

	public String execute() throws Exception{
	//何も無いのに成功はおかしいからエラー
	String	result=ERROR;

	GoCartDAO dao =new GoCartDAO();

	String uuid=(String) sessionMap.get("UUID");
	if(dao.select(uuid)){
		cartList.addAll(dao.getCartList());
		result = SUCCESS;
	}
return result;
}

	public List<GoCartDTO> getCheckList(){
		return checkList;
	}
	public void setCheckList(List<GoCartDTO> checkList) {
		this.checkList = checkList;
	}
	public List<GoCartDTO> getCartList() {
		return cartList;
	}

	public void setCartList(List<GoCartDTO> cartList) {
		this.cartList = cartList;
	}
	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSession(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}





}
