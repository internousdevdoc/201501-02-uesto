package jp.co.internous.action;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import jp.co.internous.dao.MenuDAO;
import jp.co.internous.dto.MenuDTO;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;



public class MenuAction extends ActionSupport implements SessionAware {

	public List<MenuDTO> goodsList=new ArrayList<MenuDTO>();
	public String result;
	public Map<String , Object> sessionMap;

	public String execute() throws Exception{
		System.out.println("menuAction");

		InetAddress host = InetAddress.getLocalHost();
		System.out.println("YOUR HOST = "+host);
		//sessionMap.put("HOST",host);


		String uuid = UUID.randomUUID().toString();
       // String uuidStr = uuid.toString();
System.out.println("ssssssss"+sessionMap.get("UUID"));
		if(sessionMap.get("UUID")==null){
		sessionMap.put("UUID",uuid);
		}




		result=ERROR;
		MenuDAO dao=new MenuDAO();
		boolean resultDAO=dao.select();

		if(resultDAO){
			goodsList.addAll(dao.getGoodsList());
			result=SUCCESS;

			System.out.println("MenuAction - result - "+result);
		}
		return result;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSession(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}





}
