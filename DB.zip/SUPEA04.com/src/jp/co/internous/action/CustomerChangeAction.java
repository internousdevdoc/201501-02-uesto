package jp.co.internous.action;

import jp.co.internous.dao.CustomerChangeDAO;

import com.opensymphony.xwork2.ActionSupport;


public class CustomerChangeAction extends ActionSupport{


	private String mailad;
	private int postcode;
	private String address;
	private int telnumber;
	int count;
	public String action=ERROR;

	public String execute()throws Exception{
		System.out.println("CustomerChangeAction内");

		System.out.println("Update-JSPからの値-"+mailad+"/"+postcode+"/"+address+"/"+telnumber);

		CustomerChangeDAO dao=new CustomerChangeDAO();
		System.out.println("CustomorChangeDAOに突入");

		count=dao.update(mailad,postcode,address,telnumber);

		if(count>0){
			action=SUCCESS;
		}
		return action;
	}

	public String getMailad() {
		return mailad;
	}

	public void setMailad(String mailad) {
		this.mailad = mailad;
	}

	public int getPostcode() {
		return postcode;
	}

	public void setPostcode(int postcode) {
		this.postcode = postcode;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getTelnumber() {
		return telnumber;
	}

	public void setTelnumber(int telnumber) {
		this.telnumber = telnumber;
	}

}