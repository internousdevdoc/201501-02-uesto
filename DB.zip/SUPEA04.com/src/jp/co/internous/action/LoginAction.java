package jp.co.internous.action;

import java.util.Map;

import jp.co.internous.dao.LoginDAO;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport implements SessionAware{

	public String userid;
	public String password;
	public String result;
	public Map<String,Object> sessionMap;
	public String msg;

	public String execute()throws Exception{
		result=ERROR;

		LoginDAO dao=new LoginDAO();
		if(dao.select(userid,password)){
			result=SUCCESS;
			sessionMap.put("USERID",dao.DBname);
		  }
		else{
				msg="ログインID、またはパスワードが間違っています。会員登録が済んでいない方は画面下部[新規顧客情報入力]をクリックください";
			}
		return result;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSession(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}//execute


}



