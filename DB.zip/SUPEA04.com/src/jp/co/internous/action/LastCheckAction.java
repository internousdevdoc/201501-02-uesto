package jp.co.internous.action;

import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import jp.co.internous.dao.GoCartDAO;
import jp.co.internous.dto.GoCartDTO;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public class LastCheckAction extends ActionSupport implements SessionAware{

	public String result;
	public Map<String, Object> sessionMap;
	public List<GoCartDTO> cartList = new ArrayList<GoCartDTO>();
	public String userid;
	public int total_price;

	/**
	 * 実行メソッド
	 *
	 * @author 羽田美紀
	 * @since 2015/02/16
	 * @version 1.0
	 */

	public String execute() throws Exception {

		result = ERROR;

		System.out.println("asdfghj");
		GoCartDAO dao = new GoCartDAO();

		/*
		 * for(int i=0;i<cartList.size();i++){
		 *
		 * String goods_name=cartList.get(i).getGoods_name(); int order_count =
		 * cartList.get(i).getOrder_count();
		 */

System.out.println("uuid-lastcheck:"+ sessionMap.get("UUID"));
		String uuid= (String) sessionMap.get("UUID");
		//String mac =getMacAddr();
		System.out.println("uuid:"+uuid);
		if (dao.select(uuid)) {
			result = SUCCESS;
			System.out.println("sdfghj"+result);
			cartList.addAll(dao.getCartList());
		}
		total_price=dao.select2(uuid);

		return result;
	}



	public String getMacAddr() throws SocketException {
		String s = null;
		Enumeration<NetworkInterface> nics = NetworkInterface
				.getNetworkInterfaces();
		while (nics.hasMoreElements()) {
			NetworkInterface nic = nics.nextElement();
			s = "";
			byte[] hardwareAddress = nic.getHardwareAddress();
			if (hardwareAddress != null) {
				for (byte b : hardwareAddress) {
					s += String.format("%02X ", b);
				}
			}

			if (s != "") {
				break;
			}
		}
		return s;
	}

	public List<GoCartDTO> getCartList() {
		return cartList;
	}

	public void setCartList(List<GoCartDTO> cartList) {
		this.cartList = cartList;
	}
	public int getTotal_price() {
		return total_price;
	}

	public void setTotal_price(int total_price) {
		this.total_price = total_price;
	}
	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSession(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}


}
