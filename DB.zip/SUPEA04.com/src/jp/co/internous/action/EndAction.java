package jp.co.internous.action;
import java.net.SocketException;
import java.util.Map;

import jp.co.internous.dao.GoCartDAO;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;


public class EndAction extends ActionSupport implements SessionAware{
	String result=ERROR;
	public Map<String,Object> sessionMap;

	public String execute() throws SocketException{
		GoCartDAO dao =new GoCartDAO();

		String uuid=(String) sessionMap.get("UUID");
		int count=dao.delete(uuid);

		if(count>0){
			result=SUCCESS;
		}

		return result;
	}


	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSession(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}
}
