package jp.co.internous.action;

import jp.co.internous.dao.Customer_infoDAO;

import com.opensymphony.xwork2.ActionSupport;

public class Customer_infoAction extends ActionSupport{

	public String name;
	public String userid;
	public String password;
	public String mailad;
	public String postal;
	public String address;
	public String telnum;

	public String USER;
	public String PASS;

	public String msg = null;


	public int count;
	public String result = ERROR;



	public String execute() throws Exception{

		System.out.println("■Customer_infoAction内");

		int post = Integer.parseInt(postal);

		Customer_infoDAO dao = new Customer_infoDAO();

		System.out.println("■Customer_infoDAOに突入");

		count = dao.insert(name, userid, password, mailad, post, address, telnum);

		if(count > 0){

			result = SUCCESS;

			if(dao.select(name, userid, password, mailad, post, address, telnum)){
				USER = userid;
				PASS = password;
			}

		}else{

			System.out.println("■エラー発生");
			msg = "※記入されたログインIDは使用されています";

		}
		return result;

	}//execute



	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


}//class
