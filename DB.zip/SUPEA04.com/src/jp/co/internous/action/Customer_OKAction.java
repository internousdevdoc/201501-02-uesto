package jp.co.internous.action;

import java.util.Map;

import jp.co.internous.dao.Customer_OKDAO;
import jp.co.internous.dao.LoginDAO;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public class Customer_OKAction extends ActionSupport implements SessionAware{

	public String result = ERROR;

	public String userid;
	public String password;
	public String USER;
	public String PASS;
	public String USERID;

	public Map<String, Object> sessionMap;


	public String execute() throws Exception {

		Customer_OKDAO dao = new Customer_OKDAO();
		LoginDAO dao2=new LoginDAO();

		if(dao.select(USER,PASS)){

			userid = dao.DBuserid;
			password = dao.DBpassword;
			System.out.println("IDとPASS格納完了 - "+ userid +" - "+ password);

			if(dao2.select(userid,password)){
				sessionMap.put("USERID",userid);

			result = SUCCESS;
			}

		}else{
			System.out.println("■ログインエラー発生");
		}


		return result;
	}// execute


	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}


	public void setSession(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}


}// class
