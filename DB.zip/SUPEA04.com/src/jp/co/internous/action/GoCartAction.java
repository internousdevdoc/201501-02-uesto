package jp.co.internous.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.internous.dao.GoCartDAO;
import jp.co.internous.dto.GoCartDTO;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public class GoCartAction extends ActionSupport implements SessionAware{

	public int goods_id;
	public static List<GoCartDTO> cartList = new ArrayList<GoCartDTO>();
	public String result=ERROR;
	public Map<String,Object> sessionMap;


	public String execute() throws Exception{

		GoCartDAO dao = new GoCartDAO();


		String uuid=(String) sessionMap.get("UUID");

		if(dao.insert(goods_id,uuid)){
			result = SUCCESS;
		}
		return result;
	}

	public int getGoods_id() {
		return goods_id;
	}

	public void setGoods_id(int goods_id) {
		this.goods_id = goods_id;
	}

	public static List<GoCartDTO> getCartList() {
		return cartList;
	}

	public static void setCartList(List<GoCartDTO> cartList) {
		GoCartAction.cartList = cartList;
	}
	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSession(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}



}
