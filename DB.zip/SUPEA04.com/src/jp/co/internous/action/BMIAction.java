package jp.co.internous.action;

import java.util.ArrayList;
import java.util.List;

import jp.co.internous.dao.BMIDAO;
import jp.co.internous.dto.BMIDTO;

import com.opensymphony.xwork2.ActionSupport;

public class BMIAction extends ActionSupport{

	public double hight;
	public int weight;
	public int kcal;
	public String result=ERROR;
	public List<BMIDTO> pickupList=new ArrayList<BMIDTO>();

	public String execute()throws Exception{
		result=ERROR;
		System.out.println("BMIAction - in");

	double bmi = weight/(hight*hight);



		 System.out.println("BMIAction - bmi - "+bmi);

	if(bmi<25){
		kcal=1;
	}if(bmi>30){
		kcal=3;
	}else{
		kcal=2;
	}

	System.out.println("BMIAction - kcal - "+kcal);





		System.out.println("menuAction");

		BMIDAO dao=new BMIDAO();
		boolean resultDAO=dao.select(kcal);



		if(resultDAO){
			System.out.println("BMIAction - if ");
			pickupList.addAll(dao.getPickupList());

			 result=SUCCESS;
			System.out.println("MenuAction - result - "+result);

		}




	return result;


	}

	public double getHight() {
		return hight;
	}

	public void setHight(double hight) {
		this.hight = hight;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getKcal() {
		return kcal;
	}

	public void setKcal(int kcal) {
		this.kcal = kcal;
	}






}
