package jp.co.internous.dto;

public class OrderCheckDeleteDTO {

public String goods_name;
public int price;
public int sales_numbers;
public String getGoods_name() {
	return goods_name;
}
public void setGoods_name(String goods_name) {
	this.goods_name = goods_name;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public int getSales_numbers() {
	return sales_numbers;
}
public void setSales_numbers(int sales_numbers) {
	this.sales_numbers = sales_numbers;
}





}
