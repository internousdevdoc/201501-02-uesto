package jp.co.internous.dto;

public class GoCustomerChangeDTO {
	
	public int id;
	public String customer_name;
	public String user_id;
	public String pass;
	public String mailad;
	public String postcode;
	public String address;
	public String telenumber;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getMailad() {
		return mailad;
	}
	public void setMailad(String mailad) {
		this.mailad = mailad;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTelenumber() {
		return telenumber;
	}
	public void setTelenumber(String telenumber) {
		this.telenumber = telenumber;
	}
	
	

}
