package jp.co.internous.dto;

public class Customer_OKDTO {

	private String password;
	private String userid;



	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}



}
