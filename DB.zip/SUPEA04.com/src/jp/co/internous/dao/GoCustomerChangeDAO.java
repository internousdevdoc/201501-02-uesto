package jp.co.internous.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jp.co.internous.dto.GoCustomerChangeDTO;

public class GoCustomerChangeDAO {

	Connection con;
	public String DBmailad;
	public String DBpostcode;
	public String DBaddress;
	public String DBtelenumber;
	boolean result;

	public boolean select(String user_id, String mailad, String postcode,String address,String telnumber)throws Exception{

		result=false;
		con=DBconnector.getConnection();

		try{
			String sql="select mailad=?,postcode=?,address=?,telnumber=? from customer where USER_ID='totto'";

			PreparedStatement ps2;
			ps2=con.prepareStatement(sql);
			ps2.setString(1, user_id);
			System.out.println("GCC-ps2-"+ps2);
			ResultSet rs=ps2.executeQuery();

			while(rs.next()){
				result=true;
				System.out.println("GCC select-while中");
				GoCustomerChangeDTO dto=new GoCustomerChangeDTO();
				dto.setMailad(rs.getString(1));
				DBmailad=dto.getMailad();
				dto.setPostcode(rs.getString(2));
				DBpostcode=dto.getPostcode();
				dto.setAddress(rs.getString(3));
				DBaddress=dto.getAddress();
				dto.setTelenumber(rs.getString(4));
				DBtelenumber=dto.getTelenumber();
			}//while
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			con.close();
		}//finally
		return result;
	}//select

}//class
