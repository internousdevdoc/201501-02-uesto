package jp.co.internous.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.internous.dto.GoLoginDTO;

public class GoLogionDAO {

	public List<GoLoginDTO> LastOrderCheckList = new ArrayList<GoLoginDTO>();
	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	public boolean res;
	public int order_count;

	public boolean select(int goods_id, int order_count) throws SQLException {
		res = false;
		con = DBconnector.getConnection();
		try {
			String sql = "select * from goods where GOODS_ID=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, goods_id);
			System.out.println("idをセレクトすることに成功しました");
			System.out.println("GoLoginDAO-order_count" + order_count);

			rs = ps.executeQuery();
			System.out.println("Query実行");

			while (rs.next()) {
				res = true;
				System.out.println("while文に入ったよ");
				GoLoginDTO dto = new GoLoginDTO();
				dto.setGoods_id(rs.getInt(1));
				dto.setGoods_name(rs.getString(2));
				dto.setPrice(rs.getInt(3));
				dto.setOrder_count(order_count);
				LastOrderCheckList.add(dto);
				System.out.println("********************");
				System.out.println(dto.getGoods_name());
				System.out.println(dto.getOrder_count());
				System.out.println(LastOrderCheckList);
				System.out.println("********************");

			}
		} catch (SQLException e) {
		} finally {
			con.close();
		}
		return res;
	}

	public List<GoLoginDTO> getLastOrderCheckList() {
		return LastOrderCheckList;
	}

	public void setLastOrderCheckList(List<GoLoginDTO> lastOrderCheckList) {
		LastOrderCheckList = lastOrderCheckList;
	}

	public int getOrder_count() {
		return order_count;
	}

	public void setOrder_count(int order_count) {
		this.order_count = order_count;
	}



}
