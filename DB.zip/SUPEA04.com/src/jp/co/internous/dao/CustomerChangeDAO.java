package jp.co.internous.dao;



	import java.sql.Connection;
import java.sql.PreparedStatement;





	public class CustomerChangeDAO {


		Connection con =null;


		public int update(String mailad,int postcode, String address, int telnumber) throws Exception{

			con = DBconnector.getConnection();

			int rscount=0;

			try{
				System.out.println("customerchangeDAO - 中");
				String sql="UPDATE customer SET mailad = ?,postcode = ?,address = ?,telnumber= ? where CUSTOMER_NAME=?";

				PreparedStatement ps;

				ps=con.prepareStatement(sql);
				ps.setString(1, mailad);
				ps.setInt(2,  postcode);
				ps.setString(3, address);
				ps.setInt(4, telnumber);
				ps.setString(5,"黒柳");
				System.out.println("customerchangeDAO - sql - "+ps);
				rscount = ps.executeUpdate();

				if(rscount >0){
					System.out.println("更新完了");
				}

			}catch(Exception e){
				e.printStackTrace();
			}finally{
				con.close();
			}

			return rscount;
		}//update



	}


