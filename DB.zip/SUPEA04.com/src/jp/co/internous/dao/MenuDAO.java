package jp.co.internous.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import jp.co.internous.dto.MenuDTO;


public class MenuDAO {

	Connection con;
	boolean action;

	public List<MenuDTO> goodsList=new ArrayList<MenuDTO>();

	public boolean select()throws Exception{
		System.out.println("selectメソッド実行");
		action=false;
		con=DBconnector.getConnection();

		try{
		String sql="select * from GOODS";

		PreparedStatement ps;
		ps= con.prepareStatement(sql);

		ResultSet rs=ps.executeQuery();
		System.out.println("select-sql実行");

		while(rs.next()){
			action=true;
			System.out.println("MenuDAO - while");
			MenuDTO dto=new MenuDTO();
			dto.setGoods_id(rs.getInt(1));
			dto.setGoods_name(rs.getString(2));
			dto.setStock(rs.getInt(3));
			dto.setPrice(rs.getInt(4));
			dto.setKcal(rs.getInt(5));
			goodsList.add(dto);

			System.out.println("MenuDAO - while - list "+goodsList);
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			con.close();
		}
		return action;

	}
	//JSPにリストを渡すための処理を行っている
	//JSP側でGETとは書かれていないが、GETでJSP側から呼び出されている。
	public List<MenuDTO> getGoodsList(){
		return goodsList;
	}

}
