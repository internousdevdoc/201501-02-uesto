package jp.co.internous.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.internous.dto.OrderCheck_DTO;

public class TESTOrderCheckDAO {
	Connection con;

	public boolean select(int Goods_id, String Goods_name, int Price,
			int Sales_number, int Order_count) throws Exception {
		List<OrderCheck_DTO> CheckList = new ArrayList<OrderCheck_DTO>();

		Connection con;
		boolean result;

		result = false;
		con = DBconnector.getConnection();

		try {

			String sql = "select * from cart";

			PreparedStatement ps;
			ps = con.prepareStatement(sql);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				result = true;

				OrderCheck_DTO dto = new OrderCheck_DTO();
				dto.setGoods_name(rs.getString(1));
				dto.setGoods_id(rs.getInt(2));
				dto.setSales_numbers(rs.getInt(3));
				dto.setPrice(rs.getInt(4));
				dto.setOrder_count((5));
				CheckList.add(dto);

			}

		} catch (Exception e) {

		} finally {
			con.close();
		}
		return result;
	}


	public int delete(int Goods_name, String session_id) throws Exception {

		Connection con;

		int rscount = 0;
		con = DBconnector.getConnection();

		try {
			String sql = "delete from cart where GOODS_NAME=? AND SESSION_ID=?";

			PreparedStatement ps;
			ps = con.prepareStatement(sql);
			ps.setInt(1, Goods_name);
			ps.setString(2, session_id);

			rscount = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			con.close();
		}
		//結果はActionクラスに返って、その後
		//成功か、失敗かを判断するif文に入り、成功なら、次の画面に行く

		return rscount;

	}
	public int update(int goods_id, int order_count,String session_id) throws SQLException {

		// boolean result;
		con = DBconnector.getConnection();

		int rscount = 0;
		int rscount2 = 0;

		try {
			String sql1="delete from cart where GOODS_NAME=? AND session_id=?";
			String sql2 = "insert into cart(session_id,goods_name,order_count,price,total_amount) values(?,?,?,0,0);";
			//２つのテーブルを使用し結合しているため、UPdate文を発動できない。
			//ので、２つ記載している。

			PreparedStatement ps;

			ps = con.prepareStatement(sql1);
			ps.setInt(1, goods_id);
			ps.setString(2, session_id);


			PreparedStatement ps2;


			ps2 = con.prepareStatement(sql2);
			ps2.setString(1, session_id);
			ps2.setInt(2, goods_id);
			ps2.setInt(3, order_count);


			System.out.println("sql:" + sql1);
			rscount = ps.executeUpdate();
			rscount2 = ps2.executeUpdate();

			if(rscount2==0){
				rscount=0;
			}

			System.out.println("rscount:" + rscount);
			System.out.println("rscoun2t:" + rscount2);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			con.close();
		}

		return rscount;

	}

	public List<OrderCheck_DTO> getCheckList() {
		return null;
	}

}
